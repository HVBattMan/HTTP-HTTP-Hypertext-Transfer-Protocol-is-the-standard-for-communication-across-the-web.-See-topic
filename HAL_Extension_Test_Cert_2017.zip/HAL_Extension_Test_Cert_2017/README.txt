This package contains an updated version of the "Windows OEM HAL Extension Test Cert 2017 (TEST ONLY)" certificate. This certificate is intended to replace the version bundled with previous WDK, EWDK, and ADK releases. HAL extensions test signed with the previous version of the certificate will fail to load even if testsigning is enabled. This updated certificate addresses the issue and will correctly test sign HAL extensions for use on testsigning enabled systems.

These instructions will also force signtool to use the Windows OEM 2017 test certificates. This resolves a build dependency on the expired Windows Phone OEM 2013 test certificates when using the Windows 10, version 1709 WDK, EWDK, or ADK.

Automatic Installation:
1) Run the Update_HAL_Test_Cert.cmd script as the user who will be building HAL extensions. This script will automatically run the commands from the Manual Installation section.

Manual Installation:
1) Install the updated version of the certificate using certutil:

certutil.exe -p "" -user -importpfx "OEM_HAL_Extension_Test_Cert_2017.pfx" NoRoot

2) Set the environment variable SIGNTOOL_OEM_SIGN_HAL to force HAL signing to use the new certificate:

setx.exe SIGNTOOL_OEM_SIGN_HAL "/a /u 1.3.6.1.4.1.311.61.5.1 /s my /i \"Windows OEM Intermediate 2017 (TEST ONLY)\" /n \"Windows OEM HAL Extension Test Cert 2017 (TEST ONLY)\" /fd SHA256"

3) Set the environment variable SIGNTOOL_OEM_SIGN to force OEM signing to use the 2017 test certificate:

setx.exe SIGNTOOL_OEM_SIGN "/a /s my /i \"Windows OEM Intermediate 2017 (TEST ONLY)\" /n \"Windows OEM Test Cert 2017 (TEST ONLY)\" /fd SHA256"

**NOTE** If you are using the EWDK, exit and re-launch the build environment once the above steps are completed.